package com.example.slider_minipulation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
